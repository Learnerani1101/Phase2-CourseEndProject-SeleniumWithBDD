package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ScenarioContext;
import utils.WebDriverFactory;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to perform steps before test and after test  
 */
public class Hooks {

    public static WebDriver driver;
    private ScenarioContext scenarioContext;
    
    //Constructor for Dependency Injection
    public Hooks(ScenarioContext scenarioContext) {
        this.scenarioContext = scenarioContext;
    }

    @Before
    public void setup() { 	
    	driver = WebDriverFactory.initDriver("chrome");
        //Configure implicit wait and maximize window
        driver.manage().window().maximize();
        // Use implicit waits for element availability
        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        // Navigate to the application URL
        	driver.get("https://www.pizzahut.co.in/");
        //driver.get("https://www.saucedemo.com/");
        //driver.get(appUrl);
    }
    
    /*
     public void setup() {
        // 1. Setup the browser driver using WebDriverManager
        WebDriverManager.chromedriver().setup();

        // 2. Configure browser options (optional, but recommended for clean execution)
        ChromeOptions options = new ChromeOptions();
        // options.addArguments("--headless"); // Uncomment this for headless execution
        // options.addArguments("--start-maximized"); // Maximize the window on start

        // 3. Initialize the WebDriver instance
        driver = new ChromeDriver(options);

        // 4. Configure implicit wait and maximize window
        driver.manage().window().maximize();
        // Use implicit waits for element availability
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // 5. Navigate to the application URL
        //String appUrl = "https://www.google.com"; // Replace with your application URL
        driver.get("https://simplilearn.com");
        //driver.get(appUrl);
    }
     */
    
    @AfterStep
    public void afterStep(Scenario scenario) {
        // Retrieve the string from the shared context
        String retrievedString = scenarioContext.getSharedString();
        System.out.println("String from Step Definition: " + retrievedString);
        
        // Use the string, e.g., for logging or screenshot naming
        if (scenario.isFailed()) {
        	scenario.log("Status ::FAIL "+ retrievedString);
        	System.out.println("Status ::FAIL "+ retrievedString);
        }else {
        	scenario.log("Status ::PASS "+ retrievedString);
        	System.out.println("Status ::PASS "+ retrievedString);
        }
    }
    
    
    @After
    public void tearDown(Scenario scenario) {
        // Optional: take a screenshot if the scenario fails
        if (scenario.isFailed()) {
            // Logic to capture screenshot
        	System.out.println("Yet to put any logic for test fail");
        	byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName()); 
        }

        // Close the browser instance
        if (driver != null) {
            driver.quit();
        }
    }
    
    
}



    

