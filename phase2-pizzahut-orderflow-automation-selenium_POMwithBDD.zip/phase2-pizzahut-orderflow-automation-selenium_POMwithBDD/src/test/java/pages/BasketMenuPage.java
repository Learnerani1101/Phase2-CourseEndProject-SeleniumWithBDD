package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasketMenuPage {
	WebDriver driver;
	WebDriverWait wait;

	public BasketMenuPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}
	/***************************************************************************
	 Get the Items in Basket
	 ****************************************************************************/
	@FindBy(xpath= "//h2[contains(.,'Your Basket')]/following-sibling::div[@data-synth='basket-deal-item']")
	private List<WebElement> elmCheckOutBasketItems;

	public List<String> getTheItemsInBasket() {
		String itemsInBasket ;
		List<String> list2ItemsInBasket = new ArrayList<>();
		for (WebElement childBasketItems : elmCheckOutBasketItems) {
			itemsInBasket = (((childBasketItems.getText()).split("₹"))[0]).trim();
			list2ItemsInBasket.add(itemsInBasket);
		}
		//Printing the Items Which is in Basket			 
		//System.out.println("list2ItemsInBasket in BasketMenuPage Class= "+ list2ItemsInBasket); 
		return list2ItemsInBasket ;
	}
	/******************************************************************************
	 Get item details with price from basket
	 *******************************************************************************/
	public List<String> get_ItemWithPrice_FromBasket() {	
		String itemsInBasket ;
		String itemDesc = "" ;
		List<String> list3ItemsInBasket = new ArrayList<>();
		for (WebElement childBasketItems : elmCheckOutBasketItems) {
			itemsInBasket = childBasketItems.getText().trim();
			//itemDesc = getnumber4mItem(itemsInBasket);
			list3ItemsInBasket.add(getnumber4mItem(itemsInBasket));
		}
		//Printing the Items Which is in Basket			 
		System.out.println("list3ItemsInBasket = "+ list3ItemsInBasket);
		return list3ItemsInBasket;
	}
	/**********************************************************************************************
	  Fetch Price from Basket item
	 ***********************************************************************************************/
	public String getnumber4mItem(String itemdesc) {
		String[] arrBS1 = itemdesc.split("\n");
		int sizeArr = arrBS1.length;
		int k = 0;
		String pv = "";
		int indexR = 0;
		for(k = 0 ; k<sizeArr ; k++) {
			if(arrBS1[k].contains("₹")) {
				indexR = k;			
				pv =  arrBS1[k].replace("₹", "").trim();
				break;	
			}
			//System.out.println("=== k = " + k + "each item = " + arrBS1[k]);
		}		
		//System.out.println("=== indexR = " + indexR + "price = " + pv);
		return pv ;
	}
	/***************************************************************************
	 //Retrieve the Bill details i.e Total Bill , Tax and Amount Payable
	 ****************************************************************************/
	@FindBy(xpath="//div[@id='basket']/following-sibling::div/div[2]/div/div")
	private List<WebElement> elmBillContent;

	public List<String> getPriceDetailsFromCheckOutBasket() {
		List<String> priceDetailsFromBasket = new ArrayList<>();
		for (int i = 0; i < elmBillContent.size(); i++) {
			//System.out.println("Count is: " + i);
			priceDetailsFromBasket.add(elmBillContent.get(i).getText());
		}		
		/*
		String subTotal = elmBillContent.get(0).getText();
		String taxVal = elmBillContent.get(1).getText();
		String amountPayable = elmBillContent.get(2).getText();
		String priceDetails = subTotal+ "," +"\n" + taxVal+ "," +"\n" +amountPayable;
		 */
		return priceDetailsFromBasket;		
	}//end-getPriceDetailsFromCheckOutBasket()
	/*******************************************************************************************
	 //Retrieve the content of "CheckOut" Button and Validate it contain items count and price
	 ********************************************************************************************/
	@FindBy(xpath = "//div[@class='relative']/a/span")
	private List<WebElement> elmChkBtnContent ;

	@FindBy(xpath = "//div[@class='relative']/a")
	private WebElement elmChkButton;

	//String chkItemCount, String chkItemsPrice, String chkAll
	/**
	 Value to specify for parameter String criteriaToCheck are as below :
	 1.String criteriaToCheck = "chkItemCount"
	 2.String criteriaToCheck = "chkItemsPrice"
	 3.String criteriaToCheck = "chkAll"
	 ***/
	public String getCheckOutButtonContents(String criteriaToCheck) {
		//Add code to check if checkout button is enable
		boolean isCheckOutBtnEnable = elmChkButton.isEnabled();
		String strChkOutBtnInfo = "";
		System.out.println("elmChkBtnContent.size() = " + elmChkBtnContent.size());
		String itemsCount = elmChkBtnContent.get(0).getText();// 1 item
		String itemsPrice = elmChkBtnContent.get(2).getText();//₹376.96
		//System.out.println("itemsCount = " + itemsCount); //1 item
		//System.out.println(elmChkBtnContent.get(1).getText());//Checkout
		//System.out.println("itemsPrice = " + itemsPrice);//₹376.96
		if(isCheckOutBtnEnable) {
			//String chkItemCount, String chkItemsPrice, String chkAll
			switch(criteriaToCheck) {
			case("chkItemCount"):
				strChkOutBtnInfo = "CheckOut Button is enable and it contains"+"\n"+itemsCount;
			break;
			case("chkItemsPrice"):
				strChkOutBtnInfo = "CheckOut Button is enable and it contains"+"\n"+itemsPrice;
			break;
			case("chkAll"):
				strChkOutBtnInfo = "CheckOut Button is enable and it contains"+"\n"+itemsCount+"\n"+itemsPrice;
			break;
			default:
				strChkOutBtnInfo = "CheckOut Button is enable and by default it contains"+
						"\n"+itemsCount+
						"\n"+elmChkBtnContent.get(0).getText()+
						"\n"+itemsPrice;
			}//switch end
		}else {
			strChkOutBtnInfo = "CheckOut Button is disable" ;
		}
		return strChkOutBtnInfo;
		 
	}//end -getCheckOutButtonContents()

	/*********************************************************************************
		Then User remove the Pizza item from Basket
	 *********************************************************************************/
	public void removeItemFromBasketByItemName(String itemNameToRemove) throws InterruptedException {
		//Get the Items in Basket
		int sizeBasketItem = elmCheckOutBasketItems.size();
		//System.out.println("Total Number of items before removal ::"+ sizeBasketItem);
		String strBasketItemsTemp = "";
		int indexBS = 0;
		for (WebElement childBasketItems : elmCheckOutBasketItems) {
			indexBS = elmCheckOutBasketItems.indexOf(childBasketItems) + 1 ;
			strBasketItemsTemp = childBasketItems.getText();
			//System.out.println("items in basket before removal "+ "indexBS = " + indexBS + " and strBasketItemsTemp = " + strBasketItemsTemp);			
			//Get the Removal Button for each item
			//div[@data-synth='basket-deal-item'][1]/div/div/button[starts-with(@data-synth, 'basket-item-remove')]"
			String xpathRemoveBasketItem = 
					String.format("//div[@data-synth='basket-deal-item'][%d]/div/div/button[starts-with(@data-synth, 'basket-item-remove')]", indexBS);			
			WebElement elmRemoveBasketItem = driver.findElement(By.xpath(xpathRemoveBasketItem));
			boolean isRemoveBtnDisplayed = elmRemoveBasketItem.isDisplayed();
			//System.out.println("isRemoveBtnDisplayed = "+ isRemoveBtnDisplayed);

			if(strBasketItemsTemp.contains(itemNameToRemove)) {
				wait.until(ExpectedConditions.elementToBeClickable(elmRemoveBasketItem));
				Thread.sleep(Duration.ofSeconds(5));
				elmRemoveBasketItem.click();
			}//if			
		}//for	

	}//end - removeItemFromBasketByItemName
	/*********************************************************************************
		Price tag got removed from the checkout button
	 *********************************************************************************/
	@FindBy(xpath = "//div[@class='relative']/button/span")
	private List<WebElement> elmChkBtnContentWithOutPrice ;

	@FindBy(xpath = "//div[@class='relative']/button")
	private WebElement elmChkButtonWithOutPrice ;
	//button[contains(@class,'justify-between')]//span[contains(@class,'absolute inset-0 flex-center')]
	//div[@class='relative']/button/span
	public String getChkBtnContentsWithoutPrice(String amoutPayable,String minimumOrderVal) throws InterruptedException {
		String strRes = "";
		String strChkOutBtnInfo = "";
		String itemCount = "";
		String itemPrice = "";
		wait.until(ExpectedConditions.visibilityOfAllElements(elmChkBtnContentWithOutPrice));
		Thread.sleep(Duration.ofSeconds(3));
		System.out.println("elmChkBtnContentWithOutPrice.size() = " + elmChkBtnContentWithOutPrice.size());
		for(WebElement childCHKElm :elmChkBtnContentWithOutPrice) {
			System.out.println("childCHKElm.getText() == " + childCHKElm.getText());
			if(childCHKElm.getText().contains("item")) {
				itemCount = childCHKElm.getText();
			}
			if(childCHKElm.getText().contains(amoutPayable)) {
				itemPrice = childCHKElm.getText();
			}
			strChkOutBtnInfo = strChkOutBtnInfo + "," + childCHKElm.getText();						
		}
		System.out.println("strChkOutBtnInfo = " + strChkOutBtnInfo);
		double dbPayableVal = Double.parseDouble(amoutPayable);
		double dbminOrderVal = Double.parseDouble(minimumOrderVal);
		if(dbPayableVal < dbminOrderVal) {
			if(!strChkOutBtnInfo.contains(amoutPayable)) {
				strRes = "checkout button is not displaying total price " + 
						 "as Amount Payabale is less than Minimum cart value for delivery " +
						 " and the button contain item count which is : " + itemCount;				
			}else {
				strRes = "checkout button contains price : amoutPayable = " + amoutPayable;
			}
		}else {
			strRes = "checkout button contains price " + " and " +
					 "dbPayableVal = " + dbPayableVal +
					 "dbminOrderVal = " + dbminOrderVal ;
		}
		return strRes ;
	}//end - getChkBtnContentsWithoutPrice
	/*********************************************************************************
	 * Start CheckOut Process Click on the Checkout button. The user will be
	 * navigated to the checkout page
	 **********************************************************************************/
	//xpath = "//a[contains(@href,'/order/checkout/')]")
	//xpath when Minimum delivery required message was present = 
	//"//div[@class = 'relative']/button[@data-synth='link--checkout']")
	@FindBy(xpath = "//div[@class = 'relative']/a[@data-synth='link--checkout']")
	private WebElement elmChkOutBtn;

	public void navigateToCheckOut() throws InterruptedException {			
		boolean isChkOutBtnDisplayed = elmChkOutBtn.isDisplayed();
		if (isChkOutBtnDisplayed) {
			wait.until(ExpectedConditions.elementToBeClickable(elmChkOutBtn));
			elmChkOutBtn.click();
		}		
		Thread.sleep(Duration.ofSeconds(10));
	}
	
	/*********************************************************************************
	 * And User see minimum order required pop up is getting displayed
	 **********************************************************************************/
	@FindBy(xpath = "//div[@data-synth='delivery-minimum-top']/span")
	private WebElement elmMinOrderMsg ;
	public void getMsgFromMinDeliveryPrompt() {
		//And User see minimum order required pop up is getting displayed
		//String xpathMinOrder = "div[@data-synth='delivery-minimum-top']/span" ;
		//WebElement elmMinOrderMsg = driver.findElement(By.xpath(xpathMinOrder));
		//Get the message for minimum delivery 
		String msgMinOrder = elmMinOrderMsg.getText();
		System.out.println("msgMinOrder = " + msgMinOrder);
		String xpMsg = "//div[@data-synth='delivery-minimum-top']/span" ;
		WebElement elmAlertMsg = driver.findElement(By.xpath(xpMsg));
		String minOrderMsg = elmAlertMsg.getText();
		System.out.println("minOrderMsg = " + minOrderMsg);		
		//button/span[contains(text(),'Continue Shopping')]
		String xpathCpBtn = "//button[@data-synth='link--continue-shopping']" ;
		WebElement elmCpBtn = driver.findElement(By.xpath(xpathCpBtn));
		System.out.println("elmCpBtn.isDisplayed() = " + elmCpBtn.isDisplayed());
		String xp1 = "//button[@class='icon-remove--md absolute top-0 right-0 mr-10 mt-10']" ;
		WebElement elmCloseBtn = driver.findElement(By.xpath(xp1));
		System.out.println("elmCloseBtn.isDisplayed() = " + elmCloseBtn.isDisplayed());
		elmCloseBtn.click();
		
		/*********************************************************************************
			// 2. Wait for the alert to be present (best practice to avoid timing issues)
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			Alert alert = wait.until(ExpectedConditions.alertIsPresent());
			// 3. Get the text from the alert and print it
			String alertMessage = alert.getText();
			System.out.println("Alert Text: " + alertMessage);
			// 4. Perform action on the alert:
			// To 'Accept' the alert (click 'OK'):
			alert.accept();
		 *********************************************************************************/
	}
	
}
