package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define html elements and corresponding actions of those elements from home page 
 */
public class HomePage {
	WebDriver driver ;
	WebDriverWait wait;

	public HomePage(WebDriver driver) {
		this.driver = driver ;
		PageFactory.initElements(driver, this);	
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	}

	// Verify if both Tab for Delivery is available
	@FindBy(xpath = "//span[normalize-space()='Collect From Store']")
	private WebElement elmTabCollectFromStore;

	@FindBy(xpath = "//span[normalize-space()='Delivery']")
	private WebElement elmTabDelivery;

	public boolean checkBothDeliveryTabIsPresent() {
		boolean ifBothDeliveryTabPresent = false;
		if (elmTabCollectFromStore.isEnabled() && elmTabDelivery.isEnabled()) {
			ifBothDeliveryTabPresent = true;
		}
		return ifBothDeliveryTabPresent;
	}
	// Enter Delivery Location
	@FindBy(xpath = "//input[@placeholder='Enter your location for delivery']")
	private WebElement elmLocationFinder;

	@FindBy(xpath = "//div[@class='flex flex-col']/button")
	private List<WebElement> resultLoc;

	@FindBy(xpath = "//body[contains(@class, 'ReactModal__Body')]")
	private WebElement elmModalBody;

	@FindBy(xpath = "//div[@class='pl-10 pr-10']/div[1]/img")
	private WebElement elmlocation ;

	@FindBy(xpath = "//div[@class='notification-container notification-container__basket']")
	private WebElement elmNote1 ;

	public void enterDeliveryLocation(String location) throws InterruptedException {
		WebElement elmDeliveryLocation = wait.until(ExpectedConditions.elementToBeClickable(elmLocationFinder));
		elmDeliveryLocation.sendKeys(location + Keys.SPACE);
		Thread.sleep(Duration.ofSeconds(5));
		// Verify Options for Delivery locations are available		
		wait.until(ExpectedConditions.visibilityOfAllElements(resultLoc));
		System.out.println("resultLoc Size = " + resultLoc.size());
		// Thread.sleep(Duration.ofSeconds(3));
		elmDeliveryLocation.sendKeys(Keys.ENTER);
		Thread.sleep(Duration.ofSeconds(5));
	}		

	// Select first auto populate from Delivery Location drop down option
	public void selectFirstEntryOfLocationOption() throws InterruptedException {
		// ReactModal__Body--open
		// Wait for the modal or the list of options container to appear
		/**String xpathModal = "//body[contains(@class, 'ReactModal__Body')]";
			// WebElement elmContent =
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathModal)));
		 **/
		wait.until(ExpectedConditions.visibilityOf(elmModalBody));
		String cssOptionsContainer = "div[class='pl-10 pr-10']";
		WebElement optionsContainer = wait.
				until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(cssOptionsContainer)));
		if (optionsContainer.isDisplayed()) {
			System.out.println("Options for location are displayed");
		} else {
			System.out.println("Options for location are not displayed");
		}			
		// Select the Location from Modal Container
		//String xpathlocationToSelect = "//div[@class='pl-10 pr-10']/div[1]/img";
		//WebElement elmlocation = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathlocationToSelect)));
		wait.until(ExpectedConditions.elementToBeClickable(elmlocation));
		System.out.println("Check If location is enabled to select :: " + elmlocation.isEnabled());
		elmlocation.click();
		Thread.sleep(Duration.ofSeconds(5));
	}
	//When User navigate to deals page
	public String navigateOrderDealPage() throws InterruptedException {		
		/**
		 * If operations are conducted outside business hour then Notification will
		 * appear And User won't be able to place Order Checking if notification is
		 * present
		 **/
		String notificationTxt = "";
		String resultDealPageload = "";
		boolean isNotificationPresent = elmNote1.isDisplayed();
		System.out.println("Printing isNotificationPresent =  " + isNotificationPresent);
		if (isNotificationPresent) {
			WebElement elmNote = wait.until(ExpectedConditions.elementToBeClickable(
					By.cssSelector(".notification-container.notification-container__basket")));
			List<WebElement> childElements = elmNote.findElements(By.xpath("./*"));
			// Now have a List<WebElement> containing all children.
			System.out.println("Total child elements found: " + childElements.size());
			// Iterate through the list to interact with each child element
			for (WebElement childElement : childElements) {
				notificationTxt = notificationTxt + " "+ childElement.getText();
			}
			System.out.println(" Notfication Text: " + notificationTxt);
			resultDealPageload = notificationTxt;
		} else {
			System.out.println("Notification is not there ");
			//String urlToOrder = "https://www.pizzahut.co.in/order/deals/";
			//wait.until(ExpectedConditions.urlToBe(urlToOrder));
			Thread.sleep(Duration.ofSeconds(5));
			resultDealPageload = driver.getCurrentUrl();
		}
		return resultDealPageload ;
	}//close-navigateOrderDealPage()
	
	// Validate vegetarian radio button flag is off 
	@FindBy(xpath= "//div[@class='hidden 2xl:flex w-full']/div/div/span[2]")
	WebElement elmVegRadioBtn;
	
	public boolean checkVegetarianFlagOff() throws InterruptedException {		
        boolean isVegOff = false ;
        //classValue = py-4 px-5 border rounded-full flex items-center cursor-pointer bg-grey-light border-grey-light justify-start
        //class="py-4 px-5 border rounded-full flex items-center cursor-pointer bg-green border-green justify-end"
        Thread.sleep(Duration.ofSeconds(2));
        if(elmVegRadioBtn.getAttribute("class").contains("bg-grey-light border-grey-light")) {
        	isVegOff = true;
        	System.out.println("Veg Flag Off");
        }
        return isVegOff;       
	}//close - checkVegetarianFlagOff()
	
	//click vegetarian radio button and check veg flag is on 
	@FindBy(xpath= "//div[@class='hidden 2xl:flex w-full']/div/div")
	WebElement elmRD1;
	public void clickVegRadioButton()throws InterruptedException {
	    boolean isRD1Visible = elmRD1.isDisplayed();
	    System.out.println("isRD1Visible = " + isRD1Visible );
	    elmRD1.click();
	    //elmVegRadioBtn.click();
	    Thread.sleep(Duration.ofSeconds(10));
	    String str2 = 
	    	driver.findElement(By.xpath("//div[@class='hidden 2xl:flex w-full']/div/div/span[2]")).getAttribute("class");
	    System.out.println("classValVegFlag After click : str2 = "+ str2);
	    /* 
	        O/P:
	    	isRD1Visible = true
	    	classValVegFlag After click : 
	    	str2 = py-4 px-5 border rounded-full flex items-center cursor-pointer bg-green border-green justify-end
        */
	    boolean isVegOn = false;
	    if(str2.contains("bg-green border-green")) {
	    	isVegOn = true;
        	System.out.println("Veg Flag On");
        }	    
	}//close - clickVegRadioButton()

	//====================================================================================================

	public void enterDeliveryLocation_TestV1(String location) throws InterruptedException {
		System.out.println("location received from Home Step = " + location);
		Thread.sleep(Duration.ofSeconds(5));
	}

	// Select first auto populate from Delivery Location drop down option
	public void selectFirstEntryOfLocationOption_TestV1() throws InterruptedException {
		// ReactModal__Body--open
		// Wait for the modal or the list of options container to appear
		/**String xpathModal = "//body[contains(@class, 'ReactModal__Body')]";
				// WebElement elmContent =
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathModal)));
		 **/
		System.out.println("Called to select First Entry from Location DropDown");
		Thread.sleep(Duration.ofSeconds(5));
	}


}
