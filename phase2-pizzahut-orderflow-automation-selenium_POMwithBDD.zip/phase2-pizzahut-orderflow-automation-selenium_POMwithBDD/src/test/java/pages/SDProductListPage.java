package pages;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import hooks.Hooks;
import io.cucumber.java.en.When;

public class SDProductListPage  {

	WebDriver driver ;
	
	public SDProductListPage(WebDriver driver) {
		this.driver = driver ;
		PageFactory.initElements(driver, this);		
	}
	
	
	//span[@class='title']
	@FindBy(className ="title")
	WebElement elmPageHeader;
	
	public String getProductListPageHeaderText() {
		return elmPageHeader.getText();
	}
	
}
	
	
	
	
	
	
	
	
	
	