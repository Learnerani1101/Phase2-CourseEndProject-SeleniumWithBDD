package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DrinkMenuPage {
	WebDriver driver;
	WebDriverWait wait;

	public DrinkMenuPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}
	/***************************************************************************
	 And User select Pepsi option to add into the Basket  
	 ****************************************************************************/
	@FindBy(xpath = "//div[@class='basket-placeholder']")
	private WebElement elmBasket;

	@FindBy(xpath = "//span[@data-testid='drinks']/div/a")
	private List<WebElement> elmDrinkMenus;
	public HashMap<String, Double>orderDrinksBySpecifiedDrinkName
		(String drinkToOrder,int numberOfDrinkItemToAdd)throws InterruptedException {
		boolean isDrinksMenuContainerPresent = elmBasket.isDisplayed();
		System.out.println("isDrinksMenuContainerPresent = " + isDrinksMenuContainerPresent);
		// Wait for all the menu to load
		Thread.sleep(Duration.ofSeconds(3));

		// Get Total Number of Items Under Drink Menu
		wait.until(ExpectedConditions.visibilityOfAllElements(elmDrinkMenus));
		int totalDrinkMenu = elmDrinkMenus.size();
		System.out.println("Total Items under Drink = " + totalDrinkMenu);

		int indexDrinkMenu = 0;
		String strDrinkPrice = "";
		double valDrinkPrice = 0;
		String strDrinkMenuName = "";
		int counterDrinkAdd = 0;
		HashMap<String, Double> hmDrinkMenuAdded = new HashMap<>();
		
		for (WebElement childelmDrinkMenus : elmDrinkMenus) {
			indexDrinkMenu = elmDrinkMenus.indexOf(childelmDrinkMenus)+1;		
			// Get the price of the drink menu item
			String xpathDrinkPrice = String.format("//span[@data-testid='drinks']/div/a[%d]//button/span[2]",
					indexDrinkMenu);
			//System.out.println("Generated xpathDrinkPrice: " + xpathDrinkPrice);
			WebElement elmDrinkPrice = driver.findElement(By.xpath(xpathDrinkPrice));
			strDrinkPrice = elmDrinkPrice.getText().replace("₹", "").trim();
			valDrinkPrice = Double.parseDouble(strDrinkPrice);
			System.out.println("valDrinkPrice = " + valDrinkPrice);

			// Get the name of the drink menu item
			String xpathDrinkMenuName = String.format("//span[@data-testid='drinks']/div/a[%d]/div[2]", indexDrinkMenu);
			//System.out.println("Generated xpathDrinkMenuName: " + xpathDrinkMenuName);
			WebElement elmDrinkMenuName = driver.findElement(By.xpath(xpathDrinkMenuName));
			strDrinkMenuName = (elmDrinkMenuName.getText().split("\n"))[0].trim();
			boolean checkNew_Drink = strDrinkMenuName.contains("NEW");
			if (checkNew_Drink) {
				strDrinkMenuName = strDrinkMenuName.replace("NEW", "").trim();
			}
			System.out.println("strDrinkMenuName = " + strDrinkMenuName);

			// Get the Add button for drink menu item
			String xpathDrinkMenuAdd = String
					.format("//span[@data-testid='drinks']/div/a[%d]//button[contains(.,'Add')]", indexDrinkMenu);
			WebElement elmDrinkAddBtn = driver.findElement(By.xpath(xpathDrinkMenuAdd));
			boolean isDisplayedDrinkAddBtn = elmDrinkAddBtn.isDisplayed();
			System.out.println("isDisplayedDrinkAddBtn = " + isDisplayedDrinkAddBtn);
			
			//"Masala PepsiNEW 50.6 Kcal/100ml"
			if(strDrinkMenuName.contains(drinkToOrder)) {
				wait.until(ExpectedConditions.elementToBeClickable(elmDrinkAddBtn));
				Thread.sleep(Duration.ofSeconds(2));
				elmDrinkAddBtn.click();
				hmDrinkMenuAdded.put(strDrinkMenuName, valDrinkPrice);
				counterDrinkAdd++;				
			}
			if (counterDrinkAdd == numberOfDrinkItemToAdd) {
				break;
			}

		}//end for	
		return hmDrinkMenuAdded;
	}
	/***************************************************************************
	 * Add item from "Drinks" Menu
	 ****************************************************************************/
	/*int numberOfDrinkItemToAdd = 2;// ip param
	double valPrinceRangeMax_DrinksMenu = 60.0;// ip param
	double valPrinceRangeMin_DrinksMenu = 60.0;// ip param
	String optionForOrder_DrinksMenu = "OrderAccordingToPrice";// ip param
	 */
	/*@FindBy(xpath = "//div[@class='basket-placeholder']")
	private WebElement elmBasket;

	@FindBy(xpath = "//span[@data-testid='drinks']/div/a")
	private List<WebElement> elmDrinkMenus;*/

	// Method to Add drink menu item
	public HashMap<String, Double> orderDrinksMenu_V1(int numberOfDrinkItemToAdd, double valPrinceRangeMax_DrinksMenu,
			double valPrinceRangeMin_DrinksMenu, String optionForOrder_DrinksMenu) throws InterruptedException {
		boolean isDrinksMenuContainerPresent = elmBasket.isDisplayed();
		System.out.println("isDrinksMenuContainerPresent = " + isDrinksMenuContainerPresent);
		// Wait for all the menu to load
		Thread.sleep(Duration.ofSeconds(3));

		// Get Total Number of Items Under Drink Menu
		wait.until(ExpectedConditions.visibilityOfAllElements(elmDrinkMenus));
		int totalDrinkMenu = elmDrinkMenus.size();
		System.out.println("Total Items under Drink = " + totalDrinkMenu);

		int counterDrinkAdd = 0;
		int indexDrinkMenu = 0;
		String strDrinkPrice = "";
		double valDrinkPrice = 0;
		String strDrinkMenuName = "";

		List<String> list3DrinkMenu = new ArrayList<>();
		//List<String> list4DrinkItemsInBasket = new ArrayList<>();
		HashMap<String, Double> hmDrinkMenuAdded = new HashMap<>();

		int for_itr = 0;
		// Iterate through the drink menu items
		for (WebElement childelmDrinkMenus : elmDrinkMenus) {
			for_itr = elmDrinkMenus.indexOf(childelmDrinkMenus);
			indexDrinkMenu = for_itr + 1;
			// indexDrinkMenu = elmSideMenuPrice.indexOf(childelmDrinkMenus) + 1 ;
			// Get the price of the drink menu item
			String xpathDrinkPrice = String.format("//span[@data-testid='drinks']/div/a[%d]//button/span[2]",
					indexDrinkMenu);
			//System.out.println("Generated xpathDrinkPrice: " + xpathDrinkPrice);
			WebElement elmDrinkPrice = driver.findElement(By.xpath(xpathDrinkPrice));
			strDrinkPrice = elmDrinkPrice.getText().replace("₹", "").trim();
			valDrinkPrice = Double.parseDouble(strDrinkPrice);
			//System.out.println("valDrinkPrice = " + valDrinkPrice);

			// Get the name of the drink menu item
			String xpathDrinkMenuName = String.format("//span[@data-testid='drinks']/div/a[%d]/div[2]", indexDrinkMenu);
			//System.out.println("Generated xpathDrinkMenuName: " + xpathDrinkMenuName);
			WebElement elmDrinkMenuName = driver.findElement(By.xpath(xpathDrinkMenuName));
			strDrinkMenuName = (elmDrinkMenuName.getText().split("\n"))[0].trim();
			boolean checkNew_Drink = strDrinkMenuName.contains("NEW");
			if (checkNew_Drink) {
				strDrinkMenuName = strDrinkMenuName.replace("NEW", "").trim();
			}
			//System.out.println("strDrinkMenuName = " + strDrinkMenuName);

			// Get the Add button for drink menu item
			String xpathDrinkMenuAdd = String
					.format("//span[@data-testid='drinks']/div/a[%d]//button[contains(.,'Add')]", indexDrinkMenu);
			WebElement elmDrinkAddBtn = driver.findElement(By.xpath(xpathDrinkMenuAdd));
			boolean isDisplayedDrinkAddBtn = elmDrinkAddBtn.isDisplayed();
			//System.out.println("isDisplayedDrinkAddBtn = " + isDisplayedDrinkAddBtn);

			switch (optionForOrder_DrinksMenu.toLowerCase()) {
			case "orderaccordingtoprice":
				//System.out.println("Inside switch and case = " + optionForOrder_DrinksMenu.toLowerCase());
				/*
				 * if ((valSidesMenuPrice<valPrinceRangeMax_SidesMenu
				 * )&&(valSidesMenuPrice>valPrinceRangeMin_SidesMenu)) {
				 * hmSidesMenuAdded.put(strSidesMenuName, valSidesMenuPrice);
				 **/
				if (valDrinkPrice < valPrinceRangeMax_DrinksMenu) {
					list3DrinkMenu.add(strDrinkMenuName);
					hmDrinkMenuAdded.put(strDrinkMenuName, valDrinkPrice);
					wait.until(ExpectedConditions.elementToBeClickable(elmDrinkAddBtn));
					Thread.sleep(Duration.ofSeconds(2));
					elmDrinkAddBtn.click();
					counterDrinkAdd++;
					//System.out.println("Menu added to checkout");
				} else {
					//System.out.println("Menu NOT added to checkout");
				}
				break;
			case "OrderByMenu":
				System.out.println("Inside OrderByMenu");
				break;
			default:
				System.out.println("No Option was selected");
				break;
			} // switch
			//System.out.println("for_itr = " + for_itr + " and counterDrinkAdd = " + counterDrinkAdd);
			if (counterDrinkAdd == numberOfDrinkItemToAdd) {
				break;
			}
			//System.out.println("===================================================================");
		} // for
		System.out.println("*******Print consolidated list of items which are ordered inside DrinkMenuPage Class********");
		System.out.println("hmDrinkMenuAdded = " + hmDrinkMenuAdded);
		return hmDrinkMenuAdded;
	}//end-orderDrinksMenu()
}
