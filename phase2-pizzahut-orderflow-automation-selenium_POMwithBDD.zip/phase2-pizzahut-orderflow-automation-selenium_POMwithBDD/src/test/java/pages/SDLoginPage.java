package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import hooks.Hooks;
import io.cucumber.java.en.When;

public class SDLoginPage  {

	WebDriver driver ;
	
	public SDLoginPage(WebDriver driver) {
		this.driver = driver ;
		PageFactory.initElements(driver, this);		
	}
	
	@FindBy(id="user-name")
	WebElement elmUserName;

	public void enterUserId(String userid) {
		elmUserName.sendKeys(userid);
	}
	
	//input[@id='password']
	@FindBy(id="password")
	WebElement elmPassword;
	
	public void enterUserPwd(String password) {	
		elmPassword.sendKeys(password);
	}
	
	//input[@id='login-button']
	@FindBy(id="login-button")
	WebElement elmBtnLogin;
	public void clickLoginButton() throws InterruptedException {
		System.out.println("==========================Printing result for @method = clickLoginButton()===================== ");
		System.out.println("Print if login button is displayed = "+ elmBtnLogin.isDisplayed() );
		System.out.println("is login button enable = "+ elmBtnLogin.isEnabled() );
		elmBtnLogin.click();
		Thread.sleep(Duration.ofSeconds(5));
		System.out.println("==========================End of @method = clickLoginButton()===================== ");
	}
	
	/*@When("^user enter pwd as (.+)$")
	public void enterPasswordData(String password) {
		driver.findElement(By.name("user_pwd")).sendKeys(password);
	}*/
	
	
	/*@When("user click on login button")
	public void clickLoginSubmit() {
		driver.findElement(By.name("btnlogin")).click();
	}*/
	
	
	

}
