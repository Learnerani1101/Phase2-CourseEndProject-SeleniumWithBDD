package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define step definitions for PizzasMenu page 
 */
public class PizzasMenuPage {
	WebDriver driver;
	WebDriverWait wait;

	public String addedPizzaName = "";

	public PizzasMenuPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	/***************************************************************************
	 Go to Pizzas and add any item 
	 ****************************************************************************/
	@FindBy(xpath = "//div[@class='basket-placeholder']")
	private WebElement elmBasket;

	//span[contains(@data-testid,'pizzas')]
	@FindBy(xpath = "//span[@data-testid='pizzas']/div/a")
	private List<WebElement>elmPizzasMenus ;

	public String orderPizzaMenu()throws InterruptedException {
		boolean isPizzasMenuContainerPresent = elmBasket.isDisplayed();
		System.out.println("isPizzasMenuContainerPresent = "+isPizzasMenuContainerPresent);
		// Wait for all the menu to load
		Thread.sleep(Duration.ofSeconds(5));
		int indexPizzaHeader = getIndexforPizzaHeader("Recommended") + 1;

		//Get Total Number of Menu under header "Recommended"
		//span[@data-testid='pizzas']/h2[3]/following-sibling::div[1]/a/div[2]
		String xpathPizzaItem = 
				String.format("//span[@data-testid='pizzas']/h2[%d]/following-sibling::div[1]/a/div[2]", 
						indexPizzaHeader);
		List<WebElement>elmAllPizzaItem = driver.findElements(By.xpath(xpathPizzaItem));
		int totalPizzaItem = elmAllPizzaItem.size();
		System.out.println("Total Pizza Item Under Recommended: " + totalPizzaItem);

		String pizzaToAdd = "Veggie Supreme" ;
		int indexAddBtn = 0;
		for (WebElement elmChildPizzaItem : elmAllPizzaItem) {
			String pizzaItemName = elmChildPizzaItem.getText().trim();
			//System.out.println("Pizza Name : " + pizzaItemName);
			if(pizzaItemName.contains(pizzaToAdd)) {
				addedPizzaName = pizzaItemName ;
				indexAddBtn = elmAllPizzaItem.indexOf(elmChildPizzaItem)+1 ;
				//span[@data-testid='pizzas']/h2[3]/following-sibling::div[1]/a//button[contains(.,'Add')]
				String xpathAddBtnPizza = String.format(
						"//span[@data-testid='pizzas']/h2[%d]/following-sibling::div[1]/a[%d]//button[contains(.,'Add')]", 
						indexPizzaHeader,indexAddBtn);
				WebElement elmPizzaAddBtn = driver.findElement(By.xpath(xpathAddBtnPizza));
				elmPizzaAddBtn.click();
			}//-end if				
		}//-end for
		return addedPizzaName;

	}//-end function orderPizza

	// Get the index of "Recommended" section 
	@FindBy(xpath = "//span[@data-testid='pizzas']/h2")
	static List<WebElement>elmPizzaHeaderAll;

	public static int getIndexforPizzaHeader(String nameHeaderSection) {
		//Get the Section to Order Pizza
		//String xpathCollectionHeader = "//span[@data-testid='pizzas']/h2";
		//List<WebElement>elmPizzaHeaderAll = driver.findElements(By.xpath(xpathCollectionHeader));
		int indexPizzaHeader = 0;
		// Iterate through the side menu items
		for (WebElement elmChildPizzaHeader : elmPizzaHeaderAll) {
			String headerName = elmChildPizzaHeader.getText().trim();
			//System.out.println(headerName);
			if(headerName.equals(nameHeaderSection)) {
				System.out.println("headerName equals Recommended");
				indexPizzaHeader = elmPizzaHeaderAll.indexOf(elmChildPizzaHeader);			
				break;
			}//- if header				
		}//- for header
		System.out.println("index of h2 element outside for = "+ indexPizzaHeader);
		return indexPizzaHeader ;
	}

	/****************************************************************************************
	    //span[@data-testid='pizzas']/h2[3]/following-sibling::div[1]/a	
		String xpathPizzaItem1 = 
			String.format("//span[@data-testid='pizzas']/h2[%d]/following-sibling::div[1]/a", indexPizzaHeader);
		List<WebElement>elmAllPizzaItem1 = driver.findElements(By.xpath(xpathPizzaItem1));
		int totalPizzaItem1 = elmAllPizzaItem1.size();
		System.out.println("Link Count :Total Pizza Item Under Recommended: " + totalPizzaItem1);


		// Get Total Number of Items Under Pizzas Menu
		//String xpathPizzasMenus = "//span[@data-testid='Pizzas']/div/a";
		//List<WebElement> elmPizzasMenus = driver.findElements(By.xpath(xpathPizzasMenus));
		wait.until(ExpectedConditions.visibilityOfAllElements(elmPizzasMenus));
		int totalPizzasMenu = elmPizzasMenus.size();
		System.out.println("Total Items under Pizzas Menu = " + totalPizzasMenu);

		int counterPizzasMenuAdd = 0;
		int indexPizzasMenu = 0;
		String strPizzasMenuPrice = "";
		double valPizzasMenuPrice = 0;
		String strPizzasMenuName = "";
		List<String> list1PizzasMenu = new ArrayList<>();
		//List<String> list1SideMenyItemsInBasket = new ArrayList<>();
		HashMap<String, Double> hmPizzasMenuAdded = new HashMap<>();
		int for_itr = 0;

		// Iterate through the side menu items
		for (WebElement childelmPizzasMenus : elmPizzasMenus) {
			for_itr = elmPizzasMenus.indexOf(childelmPizzasMenus);
			indexPizzasMenu = for_itr + 1;

			// Get the price of the side menu item
			String xpathPizzasMenuPrice = String.format("//span[@data-testid='sides']/div/a[%d]//button/span[2]",
					indexPizzasMenu);
			//System.out.println("Generated xpathPizzasMenuPrice: " + xpathPizzasMenuPrice);
			WebElement elmPizzasMenuPrice = driver.findElement(By.xpath(xpathPizzasMenuPrice));
			strPizzasMenuPrice = elmPizzasMenuPrice.getText().replace("₹", "").trim();
			valPizzasMenuPrice = Double.parseDouble(strPizzasMenuPrice);
			//System.out.println("valPizzasMenuPrice = " + valPizzasMenuPrice);

			// Get the name of the Pizzas menu item
			String xpathPizzasMenuName = String.format("//span[@data-testid='sides']/div/a[%d]/div[2]", indexPizzasMenu);
			//System.out.println("Generated xpathPizzasMenuName: " + xpathPizzasMenuName);
			WebElement elmPizzasMenuName = driver.findElement(By.xpath(xpathPizzasMenuName));
			strPizzasMenuName = (elmPizzasMenuName.getText().split("\n"))[0].trim();
			boolean checkNew_Pizzas = strPizzasMenuName.contains("NEW");
			if (checkNew_Pizzas) {
				strPizzasMenuName = strPizzasMenuName.replace("NEW", "").trim();
			}
			//System.out.println("strPizzasMenuName = " + strPizzasMenuName);

			// Get the Add button for Pizza menu item
			String xpathPizzasMenuAdd = String
					.format("//span[@data-testid='sides']/div/a[%d]//button[contains(.,'Add')]", indexPizzasMenu);
			WebElement elmPizzasMenuAddBtn = driver.findElement(By.xpath(xpathPizzasMenuAdd));
			boolean isDisplayedPizzasMenuAddBtn = elmPizzasMenuAddBtn.isDisplayed();
			//System.out.println("isDisplayedPizzasMenuAddBtn = " + isDisplayedPizzasMenuAddBtn);

			// optionForOrder_PizzasMenu = "OrderAccordingToPrice";
			switch (optionForOrder_PizzasMenu.toLowerCase()) {
			case "orderaccordingtoprice":
				//System.out.println("Inside switch and case = " + optionForOrder_PizzasMenu.toLowerCase());

				if ((valPizzasMenuPrice<valPrinceRangeMax_PizzasMenu )&&(valPizzasMenuPrice>valPrinceRangeMin_PizzasMenu)) {
					hmPizzasMenuAdded.put(strPizzasMenuName, valPizzasMenuPrice);
					//list1PizzasMenu.add(strPizzasMenuName);
					wait.until(ExpectedConditions.elementToBeClickable(elmPizzasMenuAddBtn));
					Thread.sleep(Duration.ofSeconds(2));
					elmPizzasMenuAddBtn.click();
					counterPizzasMenuAdd++;
					//System.out.println("Pizzas Menu added to checkout");
				} else {
					//System.out.println("Pizzas Menu NOT added to checkout");
				}

				break;
			case "OrderByMenu":
				System.out.println("Inside OrderByMenu");
				break;
			default:
				System.out.println("No Option was selected");
				break;
			} // end-switch
			//System.out.println("for_itr = " + for_itr + " and counterPizzasMenuAdd = " + counterPizzasMenuAdd);
			if (counterPizzasMenuAdd == numberOfSideItemsToAdd) {
				break;
			}
			//System.out.println("===================================================================");
		} // for
		System.out.println("*********Print consolidated list of items which are ordered inside SideMenuPage Class*************** ");
		System.out.println("list1PizzasMenu = " + list1PizzasMenu);
		System.out.println("hmPizzasMenuAdded = " + hmPizzasMenuAdded);

		return hmPizzasMenuAdded;

	}// end of orderSideMenu()
	 ********************************************************************************************/

}
