package stepdefinitions;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.Status;

import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.DrinkMenuPage;
import utils.ScenarioContext;



public class DrinkMenuSteps {
	DrinkMenuPage drinkmenupage;
	private ScenarioContext scenarioContext;

	public DrinkMenuSteps() {
		this.drinkmenupage = new DrinkMenuPage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}

	// Constructor for Dependency Injection
	public DrinkMenuSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
	}
	//And User select Pepsi option to add into the Basket
	@And("User select Pepsi option to add into the Basket")
	public void user_select_Pepsi_option_to_add_into_the_Basket() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(2));
		DrinkMenuPage drinkmenupage = new DrinkMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_select_Pepsi_option_to_add_into_the_Basket===============");
		//"Masala PepsiNEW 50.6 Kcal/100ml"
		String drinkToOrder = "Masala Pepsi";
		int numberOfDrinkItemToAdd = 1;
		HashMap<String, Double> hmDrinkMenuAdded = 
				drinkmenupage.orderDrinksBySpecifiedDrinkName(drinkToOrder,numberOfDrinkItemToAdd);
		String orderDtl = "";
		if (hmDrinkMenuAdded.isEmpty()) {
			tcStatus = "Drink Items are not added";
		} else {
			// Iterate using an enhanced for loop and entrySet()
			for (Map.Entry<String, Double> entry : hmDrinkMenuAdded.entrySet()) {
				String item = entry.getKey(); // Get the key (item name)
				Double price = entry.getValue(); // Get the value (price)
				orderDtl = orderDtl + "Drink Item Added = " + item + ": ₹" + price ;		
			}
			tcStatus =  orderDtl;
		}		
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("=====================================End of Method in Step Def==================================================");
		
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	
}