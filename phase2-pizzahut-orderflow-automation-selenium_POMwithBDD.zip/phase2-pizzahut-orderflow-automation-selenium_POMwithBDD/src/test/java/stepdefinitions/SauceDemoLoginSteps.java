package stepdefinitions;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//import Hooks.BaseTest;
import hooks.Hooks;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
//import pages.LoginPage;
import pages.SDLoginPage;

public class SauceDemoLoginSteps   {
//WebDriver driver;

	SDLoginPage sdloginpage;

	public SauceDemoLoginSteps() {
	    this.sdloginpage = new SDLoginPage(Hooks.driver); // Initialize page object using the driver from Hooks
	}
	
	@Given("User access saucedemo Login Page")
	public void user_access_saucedemo_login_page() {
		String strTitle = Hooks.driver.getTitle();
		System.out.println("========Printing result for @method = user_access_saucedemo_login_page()===========");
		System.out.println("Title = " +strTitle);
		System.out.println("========End for @method = user_access_saucedemo_login_page()===========");
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	}
		
	@When("^User enter userid as (.+)$")
	public void user_enter_userid(String userid) {
		SDLoginPage sdloginpage = new SDLoginPage(Hooks.driver);
		sdloginpage.enterUserId(userid);
		/*
		 * public void user_enter_userid_as_standard_user(String userid)
		 * Write code here that turns the phrase above into concrete actions throw
		 * new io.cucumber.java.PendingException();
		 */
	}
	
	@When("^User enter pwd as (.+)$")
	public void user_enter_pwd(String password) {
		//driver.findElement(By.name("user_pwd")).sendKeys(password);
		SDLoginPage sdloginpage = new SDLoginPage(Hooks.driver);
		sdloginpage.enterUserPwd(password);
	}
	
	@When("User click on login button")
	public void user_click_on_login_button() throws InterruptedException {
		SDLoginPage sdloginpage = new SDLoginPage(Hooks.driver);
		sdloginpage.clickLoginButton();
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		//Hooks.driver.findElement(By.className(null))
	}
	
	
}	
	/*
	@Given("User access sl")
	public void launchAndNavig() {
		//WebDriverManager.chromedriver().setup();
		//driver=new ChromeDriver();
		//driver.get("https://simplilearn.com");
		String strTitle = Hooks.driver.getTitle();
		System.out.println("====================Printing result for @method = launchAndNavig()===================== ");
		System.out.println("Title = " +strTitle);
		System.out.println("====================End for @method = launchAndNavig()===================== ");
	}
	
	@When("User click on login")
	public void clickLogin() {
		LoginPage loginpage = new LoginPage(Hooks.driver);
		//driver.findElement(By.className("login")).click();
		loginpage.navigateToLogin();
	}
	@When("user enter email")
	public void enterEmail() {
		Hooks.driver.findElement(By.name("user_login")).sendKeys("raghutest@gmail.com");
	}
	@When("^user enter email as (.+)$")
	public void enterEmailData(String email) {
		//driver.findElement(By.name("user_login")).sendKeys(email);
		LoginPage loginpage = new LoginPage(Hooks.driver);
		loginpage.enterUserEmail(email);
	}

	@When("user enter password")
	public void enterPassword() {
		Hooks.driver.findElement(By.name("user_pwd")).sendKeys("raghutest@gmail.com");
	}
	
	@When("^user enter pwd as (.+)$")
	public void enterPasswordData(String password) {
		//driver.findElement(By.name("user_pwd")).sendKeys(password);
		LoginPage loginpage = new LoginPage(Hooks.driver);
		loginpage.enterUserPwd(password);
	}

	@When("user click on login button")
	public void clickLoginSubmit() throws InterruptedException {
		//driver.findElement(By.name("btnlogin")).click();
		LoginPage loginpage = new LoginPage(Hooks.driver);
		loginpage.clickLoginButton();
	}
	

	@Then("User close application")
	public void closeBrowser() {
		//driver.close();
		//Hooks.driver.quit();
		System.out.println("Close the Browser by calling teardown() from hook");
	}
    



@When("User enter pwd as secret_sauce")
public void user_enter_pwd_as_secret_sauce() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@When("User click on login button")
public void user_click_on_login_button() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("User close the application")
public void user_close_the_application() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}


}*/
