package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//import Hooks.BaseTest;
import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

import pages.SDProductListPage;

public class SDProductListSteps   {
//WebDriver driver;

	SDProductListPage sdproductlistpage;

	public SDProductListSteps() {
	    this.sdproductlistpage = new SDProductListPage(Hooks.driver); // Initialize page object using the driver from Hooks
	}
		
	//Then User should be redirected to Product List Page
	
	@Then("User should be redirected to Product List Page")
	public void verifyProductListPageHeader() {
		SDProductListPage sdproductlistpage = new SDProductListPage(Hooks.driver);
		String ht = sdproductlistpage.getProductListPageHeaderText();
		System.out.println("==========Printing result for @method = verifyProductListPageHeader()==========");
		System.out.println("ht =="+ht);
		
	}
	
	@And ("User close the application")
	public void user_close_the_application() {
		//Hooks.driver.quit();
		System.out.println("Close the Browser by calling teardown() from hook");
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	}
}	