package stepdefinitions;

import java.time.Duration;

import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.PizzasMenuPage;
import utils.ScenarioContext;


/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define step definitions for home page 
 */

public class PizzasMenuSteps {
	PizzasMenuPage pizzasmenupage;
	private ScenarioContext scenarioContext;

	public PizzasMenuSteps() {
		this.pizzasmenupage = new PizzasMenuPage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}

	// Constructor for Dependency Injection
	public PizzasMenuSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
	}
	//When User select add button of any pizza from Recommended 
	@When("User select add button of any pizza from Recommended")
	public void user_select_add_button_of_any_pizza_from_Recommended() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5));
		PizzasMenuPage pizzasmenupage = new PizzasMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_select_add_button_of_any_pizza_from_Recommended===============");
		String returnValAddedPizza = pizzasmenupage.orderPizzaMenu();
		String[] pizzaName = returnValAddedPizza.split("\n");
		
		String a = (returnValAddedPizza.split("\n"))[0];
		//System.out.println("a = "+ a);
		
		tcStatus = "Pizza Added and added item is :"+ a;
		//System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("=====================================End of Method in Step Def==================================================");
		
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	
}