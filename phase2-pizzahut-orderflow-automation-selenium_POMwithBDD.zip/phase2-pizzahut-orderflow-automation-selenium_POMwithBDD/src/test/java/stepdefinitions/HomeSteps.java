package stepdefinitions;

//import com.aventstack.extentreports.gherkin.model.Scenario;

import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import utils.ScenarioContext;


/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define step definitions for home page 
 */

public class HomeSteps {
	HomePage homepage;
	private ScenarioContext scenarioContext;

	// Constructor injection
	/*
    public MyStepDefinitions(Scenario scenario) {
        this.scenario = scenario;
    }*/

	public HomeSteps() {
		this.homepage = new HomePage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}

	// Constructor for Dependency Injection
	public HomeSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
	}

	@Given("User launch Pizzahut application with {string}")
	public void user_launch_pizzahut_application_with(String expectedUrl) {
		String actualAppURL = Hooks.driver.getCurrentUrl().trim();
		System.out.println("====================Printing result for====="
				+ "@method = user_launch_pizzahut_application===============");
		String tcStatus_applaunch = "";
		System.out.println("Actual URL = " + actualAppURL);
		//expectedUrl = "https://www.saucedemo.com/";
		System.out.println("Expected URL = " + expectedUrl );
		if(actualAppURL.equals(expectedUrl.trim())) {
			tcStatus_applaunch = "Application launched successfully and application URL is: "+actualAppURL;
		}else {
			tcStatus_applaunch = "Application is not launched and application URL is: "+actualAppURL;
		}
		scenarioContext.setSharedString(tcStatus_applaunch);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}


	@When("User see pop up for delivery with two types of delivery options")
	public void user_see_pop_up_for_delivery_with_two_types_of_delivery_options() {		
		HomePage homepage = new HomePage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_see_pop_up_for_delivery_with_two_types_of_delivery_options===============");
		boolean ifBothDeliveryOptionPresent = homepage.checkBothDeliveryTabIsPresent();
		//boolean ifBothDeliveryOptionPresent = true;
		if (ifBothDeliveryOptionPresent) {
			tcStatus = "Both Options of Delivery are present.";
		} else {
			tcStatus = "Both Options of Delivery are not present.";
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	@Then("User type address as {string} after getting prompt to enter the same in delivery pop up")
	public void user_type_address_as_after_getting_prompt_to_enter_the_same_in_delivery_pop_up(String location) throws InterruptedException {
		HomePage homepage = new HomePage(Hooks.driver);
		System.out.println("====================Printing result for====="
				+ "@method = user_type_address_after_getting_prompt_to_enter_the_same_in_delivery_pop_up===============");
		
		//location = "City Centre Mall kolkata";
		//location = "Tollygunge metro station"
		//location = "Mani Square Kolkata" ;
		homepage.enterDeliveryLocation(location);
		//homepage.enterDeliveryLocation_TestV1(location);
		scenarioContext.setSharedString("User enters location as "+ location);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	//And User select first auto populate drop down option
	@And ("User select first auto populate drop down option")
	public void user_select_first_auto_populate_drop_down_option() throws InterruptedException {
		HomePage homepage = new HomePage(Hooks.driver);
		System.out.println("====================Printing result for====="
				+ "@method = user_select_first_auto_populate_drop_down_option===============");
		homepage.selectFirstEntryOfLocationOption();
		//homepage.selectFirstEntryOfLocationOption_TestV1();
		scenarioContext.setSharedString("User select first option from location drop down");
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	//When User navigate to deals page
	@When("User navigate to deals page")
	public void user_navigate_to_deals_page() throws InterruptedException {
		HomePage homepage = new HomePage(Hooks.driver);
		String tcStatus_navigate_to_deals_page = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_navigate_to_deals_page===============");
		//homepage.selectFirstEntryOfLocationOption();

		String resultDealPageload = homepage.navigateOrderDealPage();
		//String expectedUrlToOrder = excelUtil.getData("SidesMenuPage", 1, "DealPageURL");
		String expectedUrlToOrder = "https://www.pizzahut.co.in/order/deals/";
		System.out.println("resultDealPageload = " + resultDealPageload);
		System.out.println("expectedUrlToOrder = " + expectedUrlToOrder);
		if (expectedUrlToOrder.equals(resultDealPageload)) {
			tcStatus_navigate_to_deals_page = "Order page is loaded and URL is :" + resultDealPageload ;
		} else {
			tcStatus_navigate_to_deals_page = "Order page is not loaded and available URL: " + resultDealPageload ;
		}
		System.out.println(tcStatus_navigate_to_deals_page);
		scenarioContext.setSharedString(tcStatus_navigate_to_deals_page);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}
	
	//Then User validate vegetarian radio button flag is off
	@Then("User validate vegetarian radio button flag is off")
	public void user_validate_vegetarian_radio_button_flag_is_off() throws InterruptedException {
		HomePage homepage = new HomePage(Hooks.driver);
		String tcStatus_vegflg = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_validate_vegetarian_radio_button_flag_is_off===============");
		boolean isVegOff = homepage.checkVegetarianFlagOff();
		if (isVegOff) {
			tcStatus_vegflg = "vegetarian radio button flag is off";
		} else {
			tcStatus_vegflg = "vegetarian radio button flag is NOT off";
		}
		System.out.println(tcStatus_vegflg);
		scenarioContext.setSharedString(tcStatus_vegflg);
		
	}
		



/*

@Then("User type address as {string} after getting prompt to enter the same in delivery pop up")
public void user_type_address_as_after_getting_prompt_to_enter_the_same_in_delivery_pop_up(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}

@Then("User select first auto populate drop down option")
public void user_select_first_auto_populate_drop_down_option() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}


@Then("User type address as {string}")
public void user_type_address_as(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}
@And ("User close the application")
	public void user_close_the_application()

And User select first auto populate drop down option
@Then("User select first auto populate drop down option")
public void user_select_first_auto_populate_drop_down_option() {
    // Write code here that turns the phrase above into concrete actions
    throw new io.cucumber.java.PendingException();
}*/
}
