package stepdefinitions;

import java.time.Duration;

import com.aventstack.extentreports.Status;

import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.OrderDealPage;
import utils.ScenarioContext;


/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define step definitions for OrderDeal page 
 */

public class OrderDealSteps {
	OrderDealPage orderdealpage;
	private ScenarioContext scenarioContext;

	// Constructor injection
	/*
    public MyStepDefinitions(Scenario scenario) {
        this.scenario = scenario;
    }*/

	public OrderDealSteps() {
		this.orderdealpage = new OrderDealPage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}

	// Constructor for Dependency Injection
	public OrderDealSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
	}
	
	//And User clicks on Pizzas menu bar option
	@And ("User clicks on Pizzas menu bar option")
	public void user_clicks_on_Pizzas_menu_bar_option() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5));
		OrderDealPage orderdealpage = new OrderDealPage(Hooks.driver);
		String tcStatus_PizzaMenu = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_clicks_on_Pizzas_menu_bar_option===============");
		String resultOfLoadingSideMenu = orderdealpage.selectMenuForOrder("Pizzas");
		String expectedUrlForSidesMenu = "https://www.pizzahut.co.in/order/pizzas/";
		if (expectedUrlForSidesMenu.equals(resultOfLoadingSideMenu)) {
			tcStatus_PizzaMenu = "Pizzas Menu page is loaded and URL : " + resultOfLoadingSideMenu;
		} else {
			tcStatus_PizzaMenu = "Pizzas Menu page is not loaded ";
		}		
		System.out.println(tcStatus_PizzaMenu);
		scenarioContext.setSharedString(tcStatus_PizzaMenu);
	}
	//Then User clicks on Drinks option
	@Then("User clicks on Drinks option")
	public void user_clicks_on_Drinks_option() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5));
		OrderDealPage orderdealpage = new OrderDealPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_clicks_on_Drinks_option===============");
		String resultOfLoadingDrinkMenu = orderdealpage.selectMenuForOrder("Drinks");
		// Validate if Drinks Menu Page is loaded
		String expectedUrlForDrinkMenu = "https://www.pizzahut.co.in/order/drinks/";
		if (expectedUrlForDrinkMenu.equals(resultOfLoadingDrinkMenu)) {
			tcStatus = "Drinks Menu page is loaded and URL : " + resultOfLoadingDrinkMenu;
		} else {
			tcStatus = "Drinks Menu page is not loaded ";
		}		
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);		
	}
}
