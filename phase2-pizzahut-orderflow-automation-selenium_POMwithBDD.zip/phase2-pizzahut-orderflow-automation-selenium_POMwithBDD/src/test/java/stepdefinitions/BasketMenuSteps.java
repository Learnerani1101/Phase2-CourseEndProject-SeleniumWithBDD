package stepdefinitions;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import hooks.Hooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.BasketMenuPage;
import utils.ScenarioContext;

public class BasketMenuSteps {

	BasketMenuPage basketmenupage;
	private ScenarioContext scenarioContext;

	public BasketMenuSteps() {
		this.basketmenupage = new BasketMenuPage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}

	// Constructor for Dependency Injection
	public BasketMenuSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
	}
	//Then User see that the pizza is getting added under Your Basket 
	@Then("User see that the pizza is getting added under Your Basket")
	public void user_see_that_the_pizza_is_getting_added_under_Your_Basket()throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5));
		String retrievedString = scenarioContext.getSharedString();
		//System.out.println("Printing tcStatus from PizzasMenuPage Step Definition: " + retrievedString);
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_see_that_the_pizza_is_getting_added_under_Your_Basket===============");
		List<String> list2ItemsInBasket = new ArrayList<>();
		list2ItemsInBasket = basketmenupage.getTheItemsInBasket();
		String bmItem = (((list2ItemsInBasket.toString()).split("\n"))[1]).replace("]", "").trim();
		//System.out.println("bmItem = "+ bmItem);
		String pmItem = (retrievedString.split(":"))[1].trim();
		//System.out.println("pmItem = "+ pmItem);
		if(bmItem.contains(pmItem)) {
			tcStatus = "Added item " + pmItem+ " is found in Basket";
		}else {
			tcStatus = "Added item " + pmItem+ " is not found in Basket";
		}

		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("============================End of Method in Step Def========================================");
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}

	//And User validate pizza price plus Tax is checkout price 
	@And("User validate pizza price plus Tax is checkout price")
	public void user_validate_pizza_price_plus_Tax_is_checkout_price()throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5));
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_validate_pizza_price_plus_Tax_is_checkout_price===============");
		List<String> itemPrice4mBasket = new ArrayList<>();
		itemPrice4mBasket = basketmenupage.get_ItemWithPrice_FromBasket();
		Double pizzaPrice =0.0;
		for (String bs1Child : itemPrice4mBasket) {
			pizzaPrice = pizzaPrice+Double.parseDouble(bs1Child);
		}		
		//System.out.println("pizzaPrice == " + pizzaPrice);
		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();				
		System.out.println("*************Printing priceDetailsFromBasket.get(k)***********************");
		int basketsize = priceDetailsFromBasket.size();
		List<Double> priceInfo = new ArrayList<>();		
		int k = 0;
		String sbt1 = "";
		Double billInfo = 0.0;
		Double sum = 0.0;
		for(k=0;k<basketsize;k++) {
			//System.out.println("=======value of k = "+ k +" || and each item val = " + priceDetailsFromBasket.get(k)+"===========");
			 sbt1 = ((priceDetailsFromBasket.get(k)).split("\n"))[1].replace("₹", "");
			 billInfo = Double.parseDouble(sbt1);
			 //System.out.println("====value of k = "+ k + "|| sbt1 == "+ sbt1 + "|| billInfo == " + billInfo+"========");
			 priceInfo.add(billInfo);	 
			 if(k<basketsize-1) {
				 sum = sum + billInfo;
				 //System.out.println("=======value of k = "+ k + "|| Inside for loop sum == "+ sum);
			 }
		}
		System.out.println("Outside for loop sum == "+ sum);
		
		//if ((pizzaPrice == priceInfo.get(0)) && (sum == priceInfo.get(2)))
		//if (pizzaPrice.equals(priceInfo.get(0))) {
		System.out.println("pizzaPrice = " + pizzaPrice);
		System.out.println("priceInfo.get(0) == "+ priceInfo.get(0) );
		if ((pizzaPrice.equals(priceInfo.get(0))) && (sum.equals(priceInfo.get(2)))) {		
			tcStatus = "pizza price plus Tax is equal to checkout price";
		}else {
			tcStatus = "pizza price plus Tax is not equal to checkout price";
		}
		
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");
		
	}
	//Then User validate checkout button contains Item count
	@Then("User validate checkout button contains Item count")
	public void user_validate_checkout_button_contains_Item_count()throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_validate_checkout_button_contains_Item_count===============");
		
		int itemCount = ((basketmenupage.getTheItemsInBasket()).size());
		String itemCount4mBasket = String.valueOf(itemCount);
		System.out.println("itemCount4mBasket == "+ itemCount4mBasket);
		
		//String chkItemCount, String chkItemsPrice, String chkAll
		//public String getCheckOutButtonContents(String criteriaToCheck)
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemCount");
		System.out.println("contentChkOutBtn == " + contentChkOutBtn);
		if(contentChkOutBtn.contains(itemCount4mBasket)) {
			tcStatus = "checkout button contains Item count and it is same as items present in basket";
		}else {
			tcStatus = "checkout button is not displaying Item count and the content is :: "+ contentChkOutBtn;
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");		
	}
	//And User validate checkout button contains total price count
	@And("User validate checkout button contains total price count")
	public void user_validate_checkout_button_contains_total_price_count()throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_validate_checkout_button_contains_total_price_count===============");
		
		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();				
		int basketsize = priceDetailsFromBasket.size();
		List<String> priceInfo = new ArrayList<>();		
		int k = 0;
		String sbt1 = "";
		for(k=0;k<basketsize;k++) {
			//System.out.println("=======value of k = "+ k +" || and each item val = " + priceDetailsFromBasket.get(k)+"===========");
			 sbt1 = ((priceDetailsFromBasket.get(k)).split("\n"))[1].replace("₹", "");
			 //System.out.println("value of k = "+ k + " && sbt1 == "+ sbt1 ); 
			 priceInfo.add(sbt1);	 
		}		 
		//String chkItemCount, String chkItemsPrice, String chkAll
		//public String getCheckOutButtonContents(String criteriaToCheck)
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemsPrice");
		System.out.println("contentChkOutBtn == " + contentChkOutBtn);
		if(contentChkOutBtn.contains(priceInfo.get(2))) {
			tcStatus = "checkout button contains total price count and it is same as amount payable in bill";
		}else {
			tcStatus = "checkout button is not displaying total price count  and the content is :: "+ contentChkOutBtn;
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");		
	}
	//Then User see 2 items are showing under checkout button
	@Then("User see 2 items are showing under checkout button") 	
	public void user_see_2_items_are_showing_under_checkout_button()throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_see_2_items_are_showing_under_checkout_button===============");
		
		int itemCount = ((basketmenupage.getTheItemsInBasket()).size());
		String itemCount4mBasket = String.valueOf(itemCount);
		System.out.println("Items Count in Basket = itemCount4mBasket == "+ itemCount4mBasket);
		
		//String chkItemCount, String chkItemsPrice, String chkAll
		//public String getCheckOutButtonContents(String criteriaToCheck)
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemCount");
		System.out.println("Item Count in CheckOut Button = contentChkOutBtn == " + contentChkOutBtn);
		if(contentChkOutBtn.contains(itemCount4mBasket)) {
			tcStatus = "item count showing under checkout button = " + itemCount ;
		}else {
			tcStatus = "checkout button is not displaying Item count and the content is :: "+ contentChkOutBtn;
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");		
	}
	
	//And User see total price is now more than before
	@And("User see total price is now more than before")
	public void user_see_total_price_is_now_more_than_before()throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_see_total_price_is_now_more_than_before===============");
		
		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();				
		int basketsize = priceDetailsFromBasket.size();
		List<String> priceInfo = new ArrayList<>();		
		int k = 0;
		String sbt1 = "";
		for(k=0;k<basketsize;k++) {
			//System.out.println("=======value of k = "+ k +" || and each item val = " + priceDetailsFromBasket.get(k)+"===========");
			 sbt1 = ((priceDetailsFromBasket.get(k)).split("\n"))[1].replace("₹", "");
			 //System.out.println("value of k = "+ k + " && sbt1 == "+ sbt1 ); 
			 priceInfo.add(sbt1);	 
		}		 
		//String chkItemCount, String chkItemsPrice, String chkAll
		//public String getCheckOutButtonContents(String criteriaToCheck)
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemsPrice");
		System.out.println("contentChkOutBtn == " + contentChkOutBtn);
		//User see total price is now more than before
		if(contentChkOutBtn.contains(priceInfo.get(2))) {
			tcStatus = "total price is now more than before";
		}else {
			tcStatus = "checkout button is not displaying total price and the content is :: "+ contentChkOutBtn;
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");		
	}
	
	//Then User remove the Pizza item from Basket
	@Then("User remove the Pizza item from Basket")
	public void user_remove_the_Pizza_item_from_Basket()throws InterruptedException {
		//Thread.sleep(Duration.ofSeconds(5));		
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_remove_the_Pizza_item_from_Basket===============");
		//Get Item Count Before Removal
		int itemCountBefore = 0;
		itemCountBefore = ((basketmenupage.getTheItemsInBasket()).size());
		System.out.println("Total Number of items Before removal :: " + itemCountBefore);
				
		basketmenupage.removeItemFromBasketByItemName("Veggie Supreme");
		//Masala Pepsi
		//basketmenupage.removeItemFromBasketByItemName("Masala Pepsi");
		Thread.sleep(Duration.ofSeconds(5));
		
		int itemCountAfter = 0;
		itemCountAfter = ((basketmenupage.getTheItemsInBasket()).size());
		System.out.println("Total Number of items after removal :: " + itemCountAfter);
		
		if(itemCountAfter < itemCountBefore) {
			tcStatus = "Item is removed";
		}else {
			tcStatus = "Item is not removed";
		}
		System.out.println(tcStatus);
		scenarioContext.setSharedString(tcStatus);
		System.out.println("======================End of Method in Step Def===============================");
	}
	
	//And see Price tag got removed from the checkout button
	//@And("see Price tag got removed from the checkout button")
	//public void see_Price_tag_got_removed_from_the_checkout_button()
	//And see Price tag got reduced in the checkout button
	@And("see Price tag got reduced in the checkout button")
	public void see_Price_tag_got_reduced_in_the_checkout_button() throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = see_Price_tag_got_removed_from_the_checkout_button===============");
		
		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();				
		int basketsize = priceDetailsFromBasket.size();
		List<String> priceInfo = new ArrayList<>();		
		int k = 0;
		String sbt1 = "";
		for(k=0;k<basketsize;k++) {
			 sbt1 = ((priceDetailsFromBasket.get(k)).split("\n"))[1].replace("₹", "");		 
			 priceInfo.add(sbt1);	 
		}
			
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemsPrice");
		System.out.println("contentChkOutBtn == " + contentChkOutBtn);
		//User see total price is now more than before
		if(contentChkOutBtn.contains(priceInfo.get(2))) {
			tcStatus = "total price is reduced after removal of item";
		}else {
			tcStatus = "Content of checkout button is wrong and the content is :: "+ contentChkOutBtn;
		}
		//String amoutPayable = priceInfo.get(2);
		//String minimumOrderVal = "149.0";	
		//tcStatus = basketmenupage.getChkBtnContentsWithoutPrice(amoutPayable, minimumOrderVal);	
		
		System.out.println(tcStatus);		
		scenarioContext.setSharedString(tcStatus);	
		System.out.println("======================End of Method in Step Def===============================");
	}//end - method
	
	//And User see 1 item showing in checkout button 
	@And("User see 1 item showing in checkout button")
	public void user_see_1_item_showing_in_checkout_button() throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_see_1_item_showing_in_checkout_button===============");
		
		int itemCount = ((basketmenupage.getTheItemsInBasket()).size());
		String itemCount4mBasket = String.valueOf(itemCount);
		System.out.println("Items Count in Basket After Removing Pizza Item = itemCount4mBasket == "+ itemCount4mBasket);
		
		//String chkItemCount, String chkItemsPrice, String chkAll
		//public String getCheckOutButtonContents(String criteriaToCheck)
		String contentChkOutBtn = basketmenupage.getCheckOutButtonContents("chkItemCount");
		System.out.println("Item Count in CheckOut Button = contentChkOutBtn == " + contentChkOutBtn);
		if(contentChkOutBtn.contains(itemCount4mBasket)) {
			tcStatus = "item count is reduced after removal of Pizza item and current value is = " + itemCount ;
		}else {
			tcStatus = "checkout button is displaying incorrect Item count and the content is :: "+ contentChkOutBtn;
		}
				
		//********************************************************************************
		/*********************************************************************************
		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();				
		int basketsize = priceDetailsFromBasket.size();
		List<String> priceInfo = new ArrayList<>();		
		int k = 0;
		String sbt1 = "";
		for(k=0;k<basketsize;k++) {
			 sbt1 = ((priceDetailsFromBasket.get(k)).split("\n"))[1].replace("₹", "");		 
			 priceInfo.add(sbt1);	 
		}
		
		String amoutPayable = priceInfo.get(2);
		String minimumOrderVal = "149.0";		
		tcStatus = basketmenupage.getChkBtnContentsWithoutPrice( amoutPayable, minimumOrderVal);
		***************************************************************************************/
		System.out.println(tcStatus);		
		scenarioContext.setSharedString(tcStatus);	
		System.out.println("======================End of Method in Step Def===============================");
	}//end - method
	
	//div[@data-synth='delivery-minimum-top']/span
	//div[@data-synth='delivery-minimum-top']/span
	//Then User Clicks on Checkout button
	@Then("User Clicks on Checkout button")
	public void user_Clicks_on_Checkout_button()throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = user_Clicks_on_Checkout_button===============");
		basketmenupage.navigateToCheckOut();
		tcStatus = "User Clicks on Checkout button" ;
		System.out.println(tcStatus);		
		scenarioContext.setSharedString(tcStatus);	
		System.out.println("======================End of Method in Step Def===============================");
	}//end - method
		
	//And User see minimum order required pop up is getting displayed
	
}//end-class
