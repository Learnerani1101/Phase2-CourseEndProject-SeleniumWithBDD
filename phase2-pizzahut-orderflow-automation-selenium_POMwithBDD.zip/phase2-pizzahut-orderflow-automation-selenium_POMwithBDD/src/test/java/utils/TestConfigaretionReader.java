
/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to read properties from config.properties file 
 */
package utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TestConfigaretionReader {
	static Properties property = new Properties();

	public static void readConfigPropertyFile() throws IOException {
		// 1. Get the absolute path to the project root directory
		String userDir = System.getProperty("user.dir");

		// 2. Define the relative path to your file
		// Example: file is located at project_root/src/main/resources/myfile.txt
		String relativePath = "src/test/resources/config.properties";
		// "src/main/resources/myfile.txt";

		// 3. Combine them into a correct, OS-independent path
		Path fullPath = Paths.get(userDir, relativePath);

		// Convert the Path object to a String for the FileReader constructor
		String filePathString = fullPath.toString();

		System.out.println("Attempting to read file at: " + filePathString);
		// Attempting to read file at:
		// D:\eclipseworkspace-my-learning\phase2-selenium-automation-with-testng-project2\src\test\resources\config.properties

		try (FileReader reader = new FileReader(filePathString)) {
			// Read character by character and print to console
			property.load(reader);
			/*
			 * int character; while ((character = reader.read()) != -1) {
			 * System.out.print((char) character); }
			 */
		} catch (IOException e) {
			System.err.println("\nError reading the file: " + e.getMessage());
			e.printStackTrace();
		}

	}

	public static String getURL() {
		return property.getProperty("url");
	}

	public static String getBrowser() {
		return property.getProperty("browser");
	}

}
