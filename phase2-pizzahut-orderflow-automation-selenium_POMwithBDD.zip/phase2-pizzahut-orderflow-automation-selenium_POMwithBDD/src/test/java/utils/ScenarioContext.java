package utils;

public class ScenarioContext {
    private String sharedString;

    public void setSharedString(String value) {
        this.sharedString = value;
    }

    public String getSharedString() {
        return sharedString;
    }
}

