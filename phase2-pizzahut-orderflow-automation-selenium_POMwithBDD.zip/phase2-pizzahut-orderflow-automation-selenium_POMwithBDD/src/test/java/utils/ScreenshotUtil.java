package utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtil {
	public static void getScreenshot(WebDriver driver, String testname) throws IOException {
		TakesScreenshot shot = (TakesScreenshot) driver;
		File srcFile = shot.getScreenshotAs(OutputType.FILE);
		//Get the absolute path to the project root directory
		String userDir = System.getProperty("user.dir");
		// Ensure the directory exists
		File destDir = new File(userDir + "/Screenshots");
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		// 2. Generate a timestamp
		// The format "yyyyMMdd_HHmmss" creates a string like "20260111_171305"
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

		// 3. Combine the base name, timestamp, and extension
		String fileName = testname + "_" + timestamp + ".png";

		// 4. Create the File object
		File targetFile = new File(destDir, fileName);
		// File targetFile = new File
		// ("D:\\eclipseworkspace-my-learning\\youtube-learnpomframework\\Screenshots\\"+testname+".png");
		
		
		// 5. Copy the file from source to destination
        try {
            // Requires Apache Commons IO dependency (maven: commons-io:commons-io:2.11.0 or similar)
            FileUtils.copyFile(srcFile, targetFile);
            System.out.println("Screenshot saved at: " + targetFile.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("Failed to save screenshot: " + e.getMessage());
        }

	}

	

}