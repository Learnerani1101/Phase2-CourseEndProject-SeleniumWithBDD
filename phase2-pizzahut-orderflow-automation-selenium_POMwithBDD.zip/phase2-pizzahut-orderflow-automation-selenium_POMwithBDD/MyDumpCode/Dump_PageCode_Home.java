
public class Dump_TestCase_Home {

}

package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

/* 
 * Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
 * Purpose : This is to define html elements and corresponding actions of those elements from home page 
 */
public class HomePage {
	WebDriver driver ;
	WebDriverWait wait;
	
	public HomePage(WebDriver driver) {
		this.driver = driver ;
		PageFactory.initElements(driver, this);	
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
	}

	// Verify if both Tab for Delivery is available
	@FindBy(xpath = "//span[normalize-space()='Collect From Store']")
	private WebElement elmTabCollectFromStore;

	@FindBy(xpath = "//span[normalize-space()='Delivery']")
	private WebElement elmTabDelivery;

	public boolean checkBothDeliveryTabIsPresent() {
		boolean ifBothDeliveryTabPresent = false;
		if (elmTabCollectFromStore.isEnabled() && elmTabDelivery.isEnabled()) {
			ifBothDeliveryTabPresent = true;
		}
		return ifBothDeliveryTabPresent;
	}
	


}
