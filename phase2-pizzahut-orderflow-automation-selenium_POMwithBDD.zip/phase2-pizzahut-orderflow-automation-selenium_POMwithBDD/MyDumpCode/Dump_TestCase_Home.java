
public class Dump_TestCase_Home {

}

package stepdefinitions;

//import com.aventstack.extentreports.gherkin.model.Scenario;

import io.cucumber.java.Scenario;

import com.aventstack.extentreports.Status;

import hooks.Hooks;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pages.HomePage;
import utils.ScenarioContext;


/* 
* Project = phase2-pizzahut-orderflow-automation-selenium_POMwithBDD
* Purpose : This is to define step definitions for home page 
*/

public class HomeSteps {
	HomePage homepage;
	private ScenarioContext scenarioContext;
	
	// Constructor injection
	/*
  public MyStepDefinitions(Scenario scenario) {
      this.scenario = scenario;
  }*/
	
	public HomeSteps() {
		this.homepage = new HomePage(Hooks.driver); // Initialize page object using the driver from Hooks			
	}
	
	// Constructor for Dependency Injection
  public HomeSteps(ScenarioContext scenarioContext) {
      this.scenarioContext = scenarioContext;
  }

	@Given("User launch Pizzahut application with {string}")
	public void user_launch_pizzahut_application_with(String expectedUrl) {
		String actualAppURL = Hooks.driver.getCurrentUrl().trim();
		System.out.println("====================Printing result for====="
				+ "@method = user_launch_pizzahut_application===============");
		String tcStatus_applaunch = "";
		System.out.println("Actual URL = " + actualAppURL);
		System.out.println("Expected URL = " + expectedUrl );
		if(actualAppURL.equals(expectedUrl.trim())) {
			tcStatus_applaunch = "Application launched successfully and application URL is: "+actualAppURL;
		}else {
			tcStatus_applaunch = "Application is not launched and application URL is: "+actualAppURL;
		}
		scenarioContext.setSharedString(tcStatus_applaunch);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}
	
	
	@When("User see pop up for delivery with two types of delivery options")
	public void user_see_pop_up_for_delivery_with_two_types_of_delivery_options() {		
		HomePage homepage = new HomePage(Hooks.driver);
		String tcStatus = "";
		System.out.println("====================Printing result for====="
				+ "@method = User see pop up for delivery with two types of delivery options===============");
		boolean ifBothDeliveryOptionPresent = homepage.checkBothDeliveryTabIsPresent();		
		if (ifBothDeliveryOptionPresent) {
			tcStatus = "Both Options of Delivery are present.";
			System.out.println("Both Options of Delivery are present");
		} else {
			tcStatus = "Both Options of Delivery are not present.";
			System.out.println("Options of Delivery were not present");
		}
		scenarioContext.setSharedString(tcStatus);
		// Write code here that turns the phrase above into concrete actions
		//throw new io.cucumber.java.PendingException();
	}




	/*

@When("User see pop up for delivery asking for enter location")
public void user_see_pop_up_for_delivery_asking_for_enter_location() {
  // Write code here that turns the phrase above into concrete actions
  throw new io.cucumber.java.PendingException();
}

@Then("User type address as {string}")
public void user_type_address_as(String string) {
  // Write code here that turns the phrase above into concrete actions
  throw new io.cucumber.java.PendingException();
}

@Then("User select first auto populate drop down option")
public void user_select_first_auto_populate_drop_down_option() {
  // Write code here that turns the phrase above into concrete actions
  throw new io.cucumber.java.PendingException();
}*/
}
